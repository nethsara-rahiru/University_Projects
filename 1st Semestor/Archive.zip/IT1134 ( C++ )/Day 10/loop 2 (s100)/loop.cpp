#include<iostream>
using namespace std;

int main()
{
    int total;

    for ( int i = 0 ; i <= 100 ; i++)
    {
        total = total + i;
    }

    cout << total << endl;

    return 0;
}
