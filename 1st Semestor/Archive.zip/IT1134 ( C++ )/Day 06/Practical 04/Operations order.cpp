#include<iostream>
using namespace std;

int main()
{
    int x, y, z, a;

    x = 5+6*2;
    y = (5+6)*2;
    z = 6+7*2-3;
    a = 6+9/3-3;

    cout<<"5+6*2   = "<<x<<endl;
    cout<<"(5+6)*2 = "<<y<<endl;
    cout<<"6+7*2-3 = "<<z<<endl;
    cout<<"6+9/3-3 = "<<a<<endl;
}
