#include<iostream>
using namespace std;

int main()
{
    int a, b;

    cout<<"a : ";
    cin>>a;
    cout<<"b : ";
    cin>>b;

    cout<<endl;

    bool x=(a>b);
        cout<<x<<endl;

    bool y=(a>=b);
        cout<<y<<endl;

     bool A=(a<b);
        cout<<A<<endl;

     bool Y=(a<=b);
        cout<<Y<<endl;

     bool X=(a==b);
        cout<<X<<endl;

     bool B=(a!=b);
        cout<<B<<endl;
}
