#include<iostream>
using namespace std;

int main()
{
    int x = 20;
    int y = 5;

    cout<<"x is : "<<x<<endl;
    cout<<"y is : "<<y<<endl;

    y-=x;
    x+=3;
    cout<<"y-x = "<<y<<endl;
    cout<<"x+3 ="<<x<<endl;
}
