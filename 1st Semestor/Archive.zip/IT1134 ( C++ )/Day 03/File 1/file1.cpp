#include<iostream>
using namespace std;

int main()
{
    int _a;
    double a;
    float A;
    char a_;
    string Ab;
    bool AB;

    cout<<"Enter the integer    :";
    cin>>_a;
    cout<<"Enter the double     :";
    cin>>a;
    cout<<"Enter the float      :";
    cin>>A;
    cout<<"Enter the char       :";
    cin>>a_;
    cout<<"Enter the string     :";
    cin>>Ab;
    cout<<"Enter the bool       :";
    cin>>AB;
    cout<<endl;

    cout<<"integer is: "<<_a<<endl;
    cout<<"double is : "<<a<<endl;
    cout<<"float is  : "<<A<<endl;
    cout<<"char is   : "<<a_<<endl;
    cout<<"string is : "<<Ab<<endl;
    cout<<"bool is   : "<<AB<<endl;

    return 0;
}
