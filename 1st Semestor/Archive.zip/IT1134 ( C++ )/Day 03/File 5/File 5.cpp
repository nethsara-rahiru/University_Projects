#include<iostream>
using namespace std;

int main ()
{
    int no1;
    int no2;

    cout<<"Enter two numbers ..."<<endl;
    cin>>no1,no2;

    cout<<endl<<endl<<no1^2

}
