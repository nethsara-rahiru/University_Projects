#include<iostream>
using namespace std;

int main()
{
    int x,y;
    cout<<"Enter two numbers"<<endl;
    cout<<"X :";
    cin>>x;
    //cout<<"Y :";
    //cin>>y;

    //cout<<"X + Y = "<<x+y<<endl;
    //cout<<"X - Y = "<<x-y<<endl;
    //cout<<"X x Y = "<<x*y<<endl;
    //cout<<"X / Y = "<<x/y<<endl;
    //cout<<"X % Y = "<<x%y<<endl<<endl;
    cout<<x<<endl;
    cout<<"X++ = "<<x++<<endl;
    cout<<x<<endl;
    //cout<<"++X = "<<++x<<endl<<endl;
    //cout<<"X-- = "<<x--<<endl;
    //cout<<"--X = "<<--x<<endl;

    return 0;
}
