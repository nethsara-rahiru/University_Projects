#include<iostream>
using namespace std;

int main()
{
    int l;
    int w;
    cout<<"please enter the length :";
    cin>>l;
    cout<<"Please enter the width  :";
    cin>>w;
    cout<<endl<<"The area is     : "<<l*w<<endl;
    cout<<"The Perimter is : "<<2*(l+w)<<endl;

    return 0;
}
