#include<iostream>
using namespace std;

int main()
{
    int a = 5;
    int b = 7;

    cout << endl << "Data =>" << endl;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;

    cout << endl << "Swaped =>" << endl;

    cout << "a = " << a + b - a << endl;
    cout << "b = " << b + a - b << endl;
}
