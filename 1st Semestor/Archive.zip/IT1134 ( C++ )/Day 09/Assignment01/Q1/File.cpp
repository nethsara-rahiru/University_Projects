#include<iostream>
using namespace std;

int main()
{
    int num;
    string colr;

    cout << "Please enter your favorite color  : ";
    cin >> colr;
    cout << "Please enter your favorite number : ";
    cin >> num;

    cout << "Your favorite color is " << colr << ", and your lucky number is " << num << endl;
}
