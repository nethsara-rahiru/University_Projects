#include<iostream>
using namespace std;

int main ()
{
    int number = 5;

    if(number > 0)
    {
        cout << "Hello !";
    }
    else{
        cout << "Not Hello !";
    }

    cout << endl << "Bye !";
    return 0;
}
