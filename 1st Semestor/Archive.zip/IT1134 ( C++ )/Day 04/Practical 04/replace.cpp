
#include<iostream>
#include<cmath>
using namespace std;

int main ()
{
    string a;
    cout<<"Please enter a text : ";
    getline(cin, a);
    a[0]='Q';
    cout<<endl<<a;
}
