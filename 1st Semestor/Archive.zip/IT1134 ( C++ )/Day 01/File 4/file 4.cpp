#include<iostream>
using namespace std;

int main()
{
    string name;
    int age;

    cout<<"Hello there!"<<endl;
    cout<<"Can you please give me your Name"<<endl;
    cin>>name;
    cout<<"Now can you give me your age?"<<endl;
    cin>>age;

    cout<<"\nHi, "<<name<<" !"<<endl;

    cout<<"As I herd your are "<<age<<" years old"<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;

}
