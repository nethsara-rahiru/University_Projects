#include<iostream>
using namespace std;

int main()
{
    cout<<"Hi ! I am Nethsara"<<endl;
    cout<<"I am 21 years old";
    return 0;
}
