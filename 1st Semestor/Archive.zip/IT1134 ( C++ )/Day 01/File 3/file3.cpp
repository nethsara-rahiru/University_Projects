
#include<iostream>
using namespace std;

int main()
{
    string name;
    cout<<"What is your name"<<endl;
    cin>>name;
    cout<<"Hi ! ";
    cout<<name;
    return 0;
}
