
#include<iostream>

using namespace std;

int main()
{
    int a;
    cout<<"Enter a int"<<endl;
    cin>>a;

    string b;
    cout<<"Enter a string"<<endl;
    cin>>b;

    double c;
    cout<<"Enter a double"<<endl;
    cin>>c;

    float d;
    cout<<"Enter a float"<<endl;
    cin>>d;

    char e;
    cout<<"Enter a char"<<endl;
    cin>>e;

    bool f;
    cout<<"Enter a boolen"<<endl;
    cin>>f;

    cout<<endl;
    cout<<"This is the int    : "<<a<<endl;
    cout<<"This is the string : "<<b<<endl;
    cout<<"This is the double : "<<c<<endl;
    cout<<"This is the float  : "<<d<<endl;
    cout<<"This is the char   : "<<e<<endl;
    cout<<"This is the boolen : "<<f<<endl;

}
