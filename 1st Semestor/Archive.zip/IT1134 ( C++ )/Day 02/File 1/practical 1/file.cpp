
#include<iostream>

using namespace std;

int main()
{
    string ct;
    string con;

    cout<<"Hi There"<<endl<<"In which City do you live?"<<endl;
    cin>>ct;
    cout<<"What is your country?"<<endl;
    cin>>con;
    cout<<"You live in "<<ct<<", "<<con<<endl;
    return 0;
}
